package sg.edu.nus.memorygameteam7;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ResultScreen extends AppCompatActivity{

    protected int time;
    protected int bestTime;
    protected String playerName;
    protected TextView thisTimed, topScorer, topScorerTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_screen);

        Intent intent = getIntent();
        time = intent.getIntExtra("time",0);
        thisTimed.setText("You've completed the game in " + time + " seconds");

        thisTimed = findViewById(R.id.thisTimed);
        topScorer = findViewById(R.id.topScorer);
        topScorerTime = findViewById(R.id.topScorerTime);


        Button mainMenu = findViewById(R.id.mainMenu);
//         mainMenu.setOnClickListener(this);
    }

   /*  @Override
    public void onClick(View view){
        int id = view.getId();
        if(id == R.id.mainMenu){
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
        }
    } */

    public void bestTime(){
        SharedPreferences pref = getSharedPreferences("GAME_DATA", Context.MODE_PRIVATE);
        bestTime = pref.getInt("TOP_SCORE",0);
        SharedPreferences.Editor editor = pref.edit();

        if(time < bestTime){
            topScorer.setText("Top Scorer: " + playerName);
            topScorerTime.setText("Top Score Time: " + time + "seconds");

            editor.putInt("TOP_SCORE", time);
            editor.commit();
        }
    }
}